-- [[ Basic Keymaps ]]
require('which-key').register {
  ['<leader>x'] = { name = 'E[x]plore', _ = 'which_key_ignore' }
}

require('keymap.harpoon')

-- Keymap for Explorer
vim.keymap.set('n', '<leader>xc', ':Explore<CR>', { desc = 'at [C]urrent Directory' })
vim.keymap.set('n', '<leader>xo', ':Explore ~/.config/nvim/<CR>', { desc = 'at C[o]nfig Directory' })
vim.keymap.set('n', '<leader>xh', ':Explore ~', { desc = ' at [H]ome' })

-- Keymap for vertical movements
vim.keymap.set('n', '<C-u>', '<C-u>zz', { noremap = true, silent = true })
vim.keymap.set('n', '<C-d>', '<C-d>zz', { noremap = true, silent = true })

-- Keymap for line numbers
vim.keymap.set('n', '<leader>lr', function ()
  if vim.wo.relativenumber == true then
    vim.wo.relativenumber = false
  else
    vim.wo.relativenumber = true
  end
end, { silent = true })


-- Keymaps for better default experience
-- See `:help vim.keymap.set()`
vim.keymap.set({ 'n', 'v' }, '<Space>', '<Nop>', { silent = true })

-- Remap for dealing with word wrap
vim.keymap.set('n', 'k', "v:count == 0 ? 'gk' : 'k'", { expr = true, silent = true })
vim.keymap.set('n', 'j', "v:count == 0 ? 'gj' : 'j'", { expr = true, silent = true })

-- Remap to break out of comment
-- vim.keymap.set('i', '<C-CR>', [[ "\<Cmd>set formatoptions-=r\<CR>\<CR>\<Cmd>set formatoptions+=r\<CR>" ]], { expr = true }) 
vim.keymap.set('i', '<C-CR>', "<Cmd>set formatoptions-=r<CR><CR><Cmd>set formatoptions+=r<CR>", { expr = false })

-- Remap window movements
vim.keymap.set('n', "<leader>h", "<C-W>hzz", { silent = true  } )
vim.keymap.set('n', "<leader>j", "<C-W>jzz", { silent = true  } )
vim.keymap.set('n', "<leader>k", "<C-W>kzz", { silent = true  } )
vim.keymap.set('n', "<leader>l", "<C-W>lzz", { silent = true  } )

-- Diagnostic keymaps
vim.keymap.set('n', '[d', vim.diagnostic.goto_prev, { desc = 'Go to previous diagnostic message' })
vim.keymap.set('n', ']d', vim.diagnostic.goto_next, { desc = 'Go to next diagnostic message' })
vim.keymap.set('n', '<leader>e', vim.diagnostic.open_float, { desc = 'Open floating diagnostic message' })
vim.keymap.set('n', '<leader>q', vim.diagnostic.setloclist, { desc = 'Open diagnostics list' })

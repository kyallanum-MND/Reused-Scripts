-- Vim Options to be loaded at startup
-- See `:help vim.o`

-- Vim Options
-- Highlight on search
vim.o.hlsearch = false

-- Enable Mouse Mode
vim.o.mouse = 'a'

-- Sync clipboard between OS and Neovim
vim.o.clipboard = 'unnamedplus'

-- Enable break indent
vim.o.breakindent = true

-- Save undo history
vim.o.undofile = true

-- Case-insensitive searching UNLESS \C or capital in search
vim.o.ignorecase = true
vim.o.smartcase = true

-- Decrease update time
vim.o.updatetime = 250
vim.o.timeoutlen = 300

-- Set completeopt to have a better completion experience
vim.o.completeopt = 'menuone,noselect'

-- NOTE: you should make sure your terminal supports this
vim.o.termguicolors = true

-- Set tab options
vim.o.tabstop = 2
vim.o.expandtab = true
vim.o.sts = 2
vim.o.sw = 2

-- Vim Window-scoped Options
-- Make line numbers default
vim.wo.number = true

-- Keep signcolumn on by default
vim.wo.signcolumn = 'yes'

-- Vim Global-scoped Options
